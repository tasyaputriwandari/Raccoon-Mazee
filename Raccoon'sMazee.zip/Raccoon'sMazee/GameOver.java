import greenfoot.*;  

/**
 * Write a description of class GameOver here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GameOver extends Movers
{
    /**
     * Act - do whatever the GameOver wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void gameOver()
    {
    getImage().scale(getImage().getWidth()/2, getImage().getHeight()/2);
}
    public void act()
    {
        
    }
}
