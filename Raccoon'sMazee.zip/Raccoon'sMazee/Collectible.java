public interface Collectible {
    void collect();
}
