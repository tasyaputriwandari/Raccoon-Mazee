public interface Clickable {
    void onClick();
}
