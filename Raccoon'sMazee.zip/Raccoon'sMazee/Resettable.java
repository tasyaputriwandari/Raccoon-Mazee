public interface Resettable {
    void resetPosition();
}
