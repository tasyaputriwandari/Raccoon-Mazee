import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Chance3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Chance3 extends Chances
{
    /**
     * Act - do whatever the Chance3 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        
    }
}
