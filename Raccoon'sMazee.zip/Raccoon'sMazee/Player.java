import greenfoot.*;  

/**
 * Write a description of class ShipPlayer here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Player extends Movers
{
    /**
     * Act - do whatever the ShipPlayer wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        moveAndTurn();
    }
    
}
